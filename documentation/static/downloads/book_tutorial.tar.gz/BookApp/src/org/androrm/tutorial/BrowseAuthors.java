package org.androrm.tutorial;

import java.util.ArrayList;
import java.util.List;

import android.app.ExpandableListActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class BrowseAuthors extends ExpandableListActivity {

	private List<Author> mAuthors;
	private List<List<Book>> mBooks;
	private AuthorAdapter mAdapter;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.browse_authors);

		mAuthors = Author.objects(getApplicationContext()).all().orderBy("mName").toList();
		mBooks = new ArrayList<List<Book>>();
		createChildren();
		
		mAdapter = new AuthorAdapter(this, mAuthors, mBooks);
		getExpandableListView().setAdapter(mAdapter);
		
		Button reload = (Button) findViewById(R.id.reload);
		reload.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				reloadList();
			}
		});
	}
	
	private void createChildren() {
		mBooks.clear();
		
		for(Author author : mAuthors) {
			List<Book> books = author.getBooks(getApplicationContext()).orderBy("mTitle").toList();
			mBooks.add(books);
		}
	}
	
	private void reloadList() {
		mAuthors.clear();
		mAuthors.addAll(Author.objects(getApplicationContext()).all().orderBy("mName").toList());
		
		createChildren();
		
		mAdapter.notifyDataSetChanged();
	}
}
