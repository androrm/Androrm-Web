package org.androrm.tutorial;

import android.content.Context;

import com.orm.androrm.CharField;
import com.orm.androrm.ForeignKeyField;
import com.orm.androrm.Model;
import com.orm.androrm.QuerySet;

public class Book extends Model {

	public static final QuerySet<Book> objects(Context context) {
		return objects(context, Book.class);
	}
	
	protected CharField mTitle;
	protected ForeignKeyField<Author> mAuthor;
	
	public Book() {
		super();
		
		mTitle = new CharField();
		mAuthor = new ForeignKeyField<Author>(Author.class);
	}
	
	public void setAuthor(Author author) {
		mAuthor.set(author);
	}
	
	public Author getAuthor(Context context) {
		return mAuthor.get(context);
	}
	
	public void setTitle(String title) {
		mTitle.set(title);
	}
	
	public String getTitle() {
		return mTitle.get();
	}
}
