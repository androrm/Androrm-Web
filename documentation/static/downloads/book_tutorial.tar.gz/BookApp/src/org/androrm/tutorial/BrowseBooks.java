package org.androrm.tutorial;

import java.util.List;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class BrowseBooks extends ListActivity {

	private BookAdapter mAdapter;
	private List<Book> mBooks;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.browse_books);
		
		mBooks = Book.objects(getApplicationContext()).all().orderBy("mTitle").toList();
		
		mAdapter = new BookAdapter(this, R.layout.browse_books_list_item, mBooks);
		getListView().setAdapter(mAdapter);
		
		Button reload = (Button) findViewById(R.id.reload);
		reload.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				reloadListItems();
			}
		});
	}
	
	private void reloadListItems() {
		mBooks.clear();
		mBooks.addAll(Book.objects(getApplicationContext()).all().orderBy("mTitle").toList());
		
		mAdapter.notifyDataSetChanged();
	}
}
