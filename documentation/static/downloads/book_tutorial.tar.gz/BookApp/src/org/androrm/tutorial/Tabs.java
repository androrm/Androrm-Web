package org.androrm.tutorial;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;

import com.orm.androrm.DatabaseAdapter;
import com.orm.androrm.Model;

public class Tabs extends TabActivity {
    
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		syncDB();
		
		createTab(BrowseBooks.class, "Browse Books", R.drawable.tab_button);
		createTab(BrowseAuthors.class, "Browse Authors", R.drawable.tab_button);
		createTab(AddBook.class, "Add Book", R.drawable.tab_button);
		
		getTabHost().setCurrentTab(0);
	}
	
    private void createTab(Class<? extends Activity> activity, 
			String tabAlias,
			int drawable) {
		
		Intent intent = new Intent().setClass(this, activity);
		
		Resources res = getResources();
		TabHost tabHost = getTabHost();
		
		TabHost.TabSpec spec = tabHost
			.newTabSpec(tabAlias.toLowerCase().replace(" ", "_"))
			.setIndicator(tabAlias, res.getDrawable(drawable))
			.setContent(intent);
		
		tabHost.addTab(spec);
	}
	
    private void syncDB() {
    	List<Class<? extends Model>> models = new ArrayList<Class<? extends Model>>();
    	models.add(Author.class);
    	models.add(Book.class);
    	
    	DatabaseAdapter.setDatabaseName("books_db");
    	DatabaseAdapter adapter = new DatabaseAdapter(getApplicationContext());
    	adapter.setModels(models);
    }
}