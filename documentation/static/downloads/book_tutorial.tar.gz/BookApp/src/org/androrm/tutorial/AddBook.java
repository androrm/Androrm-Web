package org.androrm.tutorial;

import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class AddBook extends Activity {

	private static final int ADD_AUTHOR_DIALOG = 0;
	private static final int NO_AUTHOR = 1;
	private static final int NO_TITLE = 2;
	
	private List<Author> mAuthors;
	private ArrayAdapter<Author> mSpinnerAdapter;
	private Author mSelectedAuthor;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_book);
		
		mAuthors = Author.objects(getApplicationContext()).all().orderBy("mName").toList();
		
		Spinner authors = (Spinner) findViewById(R.id.spinner);
		mSpinnerAdapter = new ArrayAdapter<Author>(getApplicationContext(), 
																R.layout.spinner_item, 
																mAuthors);
		
		authors.setAdapter(mSpinnerAdapter);
		authors.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {

				mSelectedAuthor = mSpinnerAdapter.getItem(position);
			}

			@Override
			public void onNothingSelected(AdapterView<?> view) {
				
			}
			
		});
		
		Button addAuthor = (Button) findViewById(R.id.add_author);
		addAuthor.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				showDialog(ADD_AUTHOR_DIALOG);
			}
		});
		
		Button saveBook = (Button) findViewById(R.id.save);
		saveBook.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				EditText title = (EditText) findViewById(R.id.title);
				String value = title.getText().toString();
				
				if(value.trim().equals("")) {
					showDialog(NO_TITLE);
				} else {
					if(mSelectedAuthor == null) {
						mSelectedAuthor = mSpinnerAdapter.getItem(0);
					}
					
					Book book = new Book();
					book.setTitle(value);
					book.setAuthor(mSelectedAuthor);
					book.save(getApplicationContext());
					
					resetForm();
				}
			}
		});
	}
	
	private void resetForm() {
		EditText title = (EditText) findViewById(R.id.title);
		title.setText("");
		
		Spinner authors = (Spinner) findViewById(R.id.spinner);
		authors.setSelection(0);
	}
	
	public void addAuthor(Author author) {
		mAuthors.clear();
		mAuthors.addAll(Author.objects(getApplicationContext()).all().orderBy("mName").toList());
		
		mSelectedAuthor = null;
		mSpinnerAdapter.notifyDataSetChanged();
	}
	
	private Dialog createAlertDialog(String msg) {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage(msg)
			   .setPositiveButton("OK", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
		
		return builder.create();
	}
	
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
			case ADD_AUTHOR_DIALOG: {
				AddAuthorDialog dialog = new AddAuthorDialog(this);
				return dialog;
			}
			case NO_AUTHOR: {
				return createAlertDialog("You did not select an author");
			}
			case NO_TITLE: {
				return createAlertDialog("Please enter the title of this book");
			}
		}
		
		return null;
	}
}
