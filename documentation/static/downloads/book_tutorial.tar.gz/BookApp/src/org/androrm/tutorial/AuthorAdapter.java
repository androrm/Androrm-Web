package org.androrm.tutorial;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class AuthorAdapter extends BaseExpandableListAdapter {

	private Context mContext;
	private List<Author> mAuthors;
	private List<List<Book>> mBooks;
	
	public AuthorAdapter(Context context, List<Author> authors, List<List<Book>> books) {
		mContext = context;
		mAuthors = authors;
		mBooks = books;
	}
	
	private View createView(String name, View convertView) {
		LinearLayout childView;
		
		if(convertView == null) {
			childView = new LinearLayout(mContext);
			LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			inflater.inflate(R.layout.browse_authors_list_item, childView, true);
		} else {
			childView = (LinearLayout) convertView;
		}
		
		TextView value = (TextView) childView.findViewById(R.id.name);
		value.setText(name);
		
		return childView;
	}
	
	@Override
	public Book getChild(int groupPosition, int childPosition) {
		return mBooks.get(groupPosition).get(childPosition);
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {

		Book book = getChild(groupPosition, childPosition);
		
		return createView(book.getTitle(), convertView);
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return mBooks.get(groupPosition).size();
	}

	@Override
	public Author getGroup(int groupPosition) {
		return mAuthors.get(groupPosition);
	}

	@Override
	public int getGroupCount() {
		return mAuthors.size();
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {

		Author author = getGroup(groupPosition);
		
		return createView(author.getName(), convertView);
	}

	@Override
	public boolean hasStableIds() {
		return true;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}

}
