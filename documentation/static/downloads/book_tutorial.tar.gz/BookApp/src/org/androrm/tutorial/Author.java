package org.androrm.tutorial;

import android.content.Context;

import com.orm.androrm.CharField;
import com.orm.androrm.Model;
import com.orm.androrm.OneToManyField;
import com.orm.androrm.QuerySet;

public class Author extends Model {

	public static final QuerySet<Author> objects(Context context) {
		return objects(context, Author.class);
	}
	
	protected CharField mName;
	protected OneToManyField<Author, Book> mBooks;
	
	public Author() {
		super();
		
		mName = new CharField();
		mBooks = new OneToManyField<Author, Book>(Author.class, Book.class);
	}
	
	public void setName(String name) {
		mName.set(name);
	}
	
	public String getName() {
		return mName.get();
	}
	
	public void addBook(Book book) {
		mBooks.add(book);
	}
	
	public QuerySet<Book> getBooks(Context context) {
		return mBooks.get(context, this);
	}
	
	@Override
	public String toString() {
		return mName.get();
	}
}
