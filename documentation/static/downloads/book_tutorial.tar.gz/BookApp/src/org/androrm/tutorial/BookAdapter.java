package org.androrm.tutorial;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BookAdapter extends ArrayAdapter<Book> {

	private Context mContext;
	private int mResource;
	
	public BookAdapter(Context context, int textViewResourceId,
			List<Book> objects) {
		super(context, textViewResourceId, objects);

		mResource = textViewResourceId;
		mContext = context;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		LinearLayout childView;
		
		Book book = getItem(position);
		
		if(convertView == null) {
			childView = new LinearLayout(mContext);
			LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			inflater.inflate(mResource, childView, true);
		} else {
			childView = (LinearLayout) convertView;
		}
		
		TextView title = (TextView) childView.findViewById(R.id.title);
		title.setText(book.getTitle());
		
		TextView author = (TextView) childView.findViewById(R.id.author);
		author.setText(book.getAuthor(mContext).getName());
	
		return childView;
	}

}
